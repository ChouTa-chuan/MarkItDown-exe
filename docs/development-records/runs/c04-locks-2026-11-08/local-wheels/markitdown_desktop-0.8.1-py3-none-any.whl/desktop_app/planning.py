"""轉換前驗證：檢查格式與裝置需求，建立保守 RAM 估算及處理計畫。"""
from .core import Plan, Request, UnsupportedFormat, Quality
from .resources import MIB


def analyze(request: Request) -> Plan:
    if request.component_id is not None or request.component_version is not None:
        from .components.contracts import _name, Version
        if request.ocr_backend!='managed_cpu': raise ValueError('元件版本選擇只適用於受管 CPU OCR。')
        if request.component_id is not None: _name(request.component_id)
        if request.component_version is not None: Version.parse(request.component_version)
    if request.device not in ("auto", "cpu", "gpu"):
        raise ValueError("不支援的運算裝置設定。")
    if type(request.cpu_threads) is not int or not 1 <= request.cpu_threads <= 256:
        raise ValueError("CPU 執行緒上限須介於 1 至 256。")
    if not request.source.is_file():
        raise FileNotFoundError(request.source)
    suffix = request.source.suffix.lower()
    if suffix not in {".txt", ".md", ".docx", ".pptx", ".xlsx", ".pdf", ".html", ".htm"}:
        raise UnsupportedFormat(f"尚未整合 {suffix or '無副檔名'} 格式。")
    if request.source.resolve() == request.destination.resolve():
        raise ValueError("輸出不得覆蓋來源。")
    if request.destination.exists() or request.destination.is_symlink():
        raise FileExistsError(request.destination)
    if suffix in {".txt", ".md"}:
        return Plan(("stream_utf8", "atomic_export"), 8*MIB,
                    "純文字使用原生解析，不需 OCR 或 GPU；以固定區塊處理。")
    # 這是保守預估，不是硬性配置保證；Office 解壓後可能遠大於檔案大小，仍需持續監控。
    estimate = max(256*MIB, request.source.stat().st_size*12)
    if suffix == ".pdf" and request.quality == Quality.PRECISE:
        from .devices import ocr_backend
        ocr_backend(request.device, request.ocr_backend)
        if request.ocr_backend in ("onnx", "onnx_verify"):
            estimate = max(estimate, 768*MIB)
        return Plan(("analyze_pages", "native_or_ocr", "atomic_export"), estimate,
                    "PDF 逐頁自動選擇原生解析或本機 OCR，必要時提供品質提醒。")
    return Plan(("markitdown_local", "atomic_export"), estimate,
                "使用本機 MarkItDown 解析；尚未加入掃描 OCR 與精準版面重試。")
